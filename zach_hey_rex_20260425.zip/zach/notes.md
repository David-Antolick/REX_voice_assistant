
## Session 2026-04-25 20:59:41
- Contributor: `zach`
- Phrase: `hey rex`
- Saved: 95 files (indices 001-095)
- Peak levels: min=0.02 avg=0.07 max=0.90
- RMS levels: min=0.002 avg=0.007 max=0.103
- Output dir: `C:\Users\racha\.rex\wake_training\recordings\zach`
