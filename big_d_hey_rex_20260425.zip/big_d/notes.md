
## Session 2026-04-25 21:39:36
- Contributor: `big D`
- Phrase: `hey rex`
- Saved: 100 files (indices 001-100)
- Peak levels: min=0.03 avg=0.19 max=0.87
- RMS levels: min=0.003 avg=0.016 max=0.081
- Output dir: `C:\Users\lilma\.rex\wake_training\recordings\big_d`
